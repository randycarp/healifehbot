# Deploy notes

This project was cleaned by Host Ding Ding Dong.

## Build settings

- Install command: `npm install`
- Build command: `npm run build` (runs `vite build`)
- Output directory: `dist`

## Platform notes

- **Vercel**: import the project, framework preset should auto-detect. `vercel.json` already has an SPA rewrite to `index.html`.
- **Netlify**: drag the unzipped folder onto https://app.netlify.com/drop, or connect the repo with the build settings above. `public/_redirects` handles client-side routing.
- **Cloudflare Pages**: same build settings. `_redirects` ships inside the build output automatically.

If any files were flagged during cleaning for mentioning a Hostinger-internal URL, search for them before you deploy — they were left untouched on purpose since editing app logic automatically is risky.
