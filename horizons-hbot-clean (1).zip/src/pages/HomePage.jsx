import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowRight, Check, Loader2 } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import Seo from '@/components/Seo';

const HERO_IMAGE = 'https://horizons-cdn.hostinger.com/4d55c2bf-08e2-474e-b56f-8a3bc4d10682/1166b75030330c8ff0f66ad4b8849360.jpg';

const MARQUEE = ['ISO:9001', 'ISO:13485', 'FDA listing', 'RoHS (safety report of materials)', 'Japanese designed', 'lifetime support', 'since 2018', 'Japanese Quality'];

const SEO_TITLE = 'Hyperbaric Chamber for Sale | HBOT & Home Hyperbaric Oxygen Chambers — Healife HBOT';

const PILLARS = [
    {
        no: '01',
        title: 'Home Hyperbaric Chamber for Everyday Wellness',
        body: 'Buy a hyperbaric chamber built for the home. Our home hyperbaric chamber range brings professional-grade hyperbaric oxygen therapy into your own space, delivering effective mild HBOT for recovery, wellness, and performance.',
    },
    {
        no: '02',
        title: 'Soft & Hard Shell Hyperbaric Chamber Options',
        body: 'Choose the configuration that fits your space and routine — a portable soft hyperbaric chamber or a durable hard shell hyperbaric chamber. Every hyperbaric oxygen chamber for sale is engineered for reliable daily use and long-term reliability.',
    },
    {
        no: '03',
        title: 'Monoplace Hyperbaric Chamber with 24/7 Support',
        body: 'Our monoplace hyperbaric chamber is designed for single-person sessions with precise pressure control. A dedicated support team is available around the clock to help with setup, technical questions, and ongoing advice for your HBOT chamber.',
    },
    {
        no: '04',
        title: 'Premium Build Quality with Global Shipping',
        body: 'When you buy a hyperbaric chamber from Healife, you get a hyperbaric oxygen therapy chamber designed to high standards and engineered for daily use. We ship our HBOT chamber for sale to customers across the globe.',
    },
];

const HomePage = () => {
    const [email, setEmail] = useState('');
    const [status, setStatus] = useState('idle');
    const [error, setError] = useState('');

    const submit = async (event) => {
        event.preventDefault();
        if (status === 'loading') return;
        const value = email.trim();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) {
            setError('Please enter a valid email address.');
            return;
        }
        setError('');
        setStatus('loading');
        try {
            await pb.collection('subscribers').create({ email: value, source: 'coming-soon' });
            setStatus('done');
        } catch (err) {
            if (err?.status === 400) {
                setStatus('done');
                return;
            }
            setStatus('idle');
            setError('Something went wrong. Please try again in a moment.');
        }
    };

    return (
        <div className="relative min-h-[100dvh] overflow-hidden bg-ink text-bone">
            <Helmet>
                <title>{SEO_TITLE}</title>
                <meta
                    name="description"
                    content="Healife HBOT has a hyperbaric chamber for sale — soft and hard shell home hyperbaric chamber options, monoplace hyperbaric oxygen therapy chambers, and HBOT chambers for sale with global shipping. Join the launch list."
                />
                <link rel="canonical" href="https://healifehbot.com/" />
                <meta name="robots" content="index, follow" />
                <html lang="en" />
            </Helmet>
            <Seo
                title={SEO_TITLE}
                description="Buy a hyperbaric chamber from Healife HBOT — soft and hard shell home hyperbaric chambers, monoplace hyperbaric oxygen therapy chambers, and HBOT chambers for sale. Join the launch list."
                image={HERO_IMAGE}
                siteName="Healife HBOT"
            />

            <div className="pointer-events-none fixed inset-0 z-0 opacity-[0.055] [background-image:radial-gradient(rgba(255,255,255,0.9)_1px,transparent_1px)] [background-size:3px_3px]" />
            <div className="pointer-events-none absolute -left-40 -top-52 z-0 h-[36rem] w-[36rem] rounded-full bg-ember/20 blur-[140px]" />

            <header className="relative z-10 mx-auto flex w-full max-w-[90rem] items-center justify-between px-6 py-8 md:px-12">
                <a href="#top" className="flex items-baseline gap-2">
                    <span className="font-display text-2xl tracking-tight">Healife HBOT</span>
                    <span className="h-1.5 w-1.5 translate-y-[-2px] rounded-full bg-ember" />
                </a>
                <a
                    href="#signup"
                    className="border-b border-bone/25 pb-0.5 text-xs uppercase tracking-[0.28em] text-bone/70 transition hover:border-ember hover:text-bone"
                >
                    Early access
                </a>
            </header>

            <main id="top" className="relative z-10">
                <section className="mx-auto grid w-full max-w-[90rem] items-center gap-14 px-6 pb-24 pt-8 md:px-12 lg:grid-cols-[1.05fr_0.95fr] lg:gap-20 lg:pt-16">
                    <div>
                        <motion.p
                            initial={{ opacity: 0, y: 12 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.5, ease: 'easeOut' }}
                            className="mb-8 inline-flex items-center gap-3 rounded-full border border-bone/15 px-4 py-1.5 text-[0.68rem] uppercase tracking-[0.3em] text-bone/60"
                        >
                            <span className="relative flex h-1.5 w-1.5">
                                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-ember opacity-70" />
                                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-ember" />
                            </span>
                            Premium chambers coming soon
                        </motion.p>

                        <motion.h1
                            initial={{ opacity: 0, y: 18 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6, delay: 0.06, ease: 'easeOut' }}
                            className="font-display text-[clamp(3rem,7.4vw,6.1rem)] font-medium leading-[0.92] tracking-[-0.03em]"
                        >
                            Healife HBOT
                            <br />
                            <span className="relative inline-block">
                                <span className="relative z-10">coming soon.</span>
                                <motion.span
                                    aria-hidden="true"
                                    initial={{ scaleX: 0 }}
                                    animate={{ scaleX: 1 }}
                                    transition={{ duration: 0.75, delay: 0.75, ease: 'easeOut' }}
                                    className="absolute bottom-1 left-0 z-0 h-[0.42em] w-full origin-left -skew-x-6 rounded-[2px] bg-ember/35"
                                />
                            </span>
                        </motion.h1>

                        <motion.p
                            initial={{ opacity: 0, y: 14 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6, delay: 0.16, ease: 'easeOut' }}
                            className="mt-8 max-w-xl text-lg leading-relaxed text-bone/65"
                        >
                            A hyperbaric chamber for sale designed to bring comfort, quality and advanced wellness technology into one considered experience. Explore soft and hard shell home hyperbaric chamber options and join the list for launch updates.
                        </motion.p>

                        <motion.form
                            id="signup"
                            onSubmit={submit}
                            initial={{ opacity: 0, y: 14 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6, delay: 0.24, ease: 'easeOut' }}
                            className="mt-10 max-w-xl scroll-mt-24"
                        >
                            {status === 'done' ? (
                                <div className="flex items-center gap-3 border-l-2 border-ember bg-bone/[0.04] px-5 py-5">
                                    <Check className="h-5 w-5 shrink-0 text-ember" strokeWidth={1.75} />
                                    <p className="text-sm leading-relaxed text-bone/80">
                                        You are on the list. We will write once, when your invitation is ready — nothing else.
                                    </p>
                                </div>
                            ) : (
                                <>
                                    <label htmlFor="email" className="mb-2 block text-xs uppercase tracking-[0.26em] text-bone/50">
                                        Get your invitation first
                                    </label>
                                    <div className="flex flex-col gap-3 sm:flex-row">
                                        <input
                                            id="email"
                                            type="email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            placeholder="you@studio.com"
                                            autoComplete="email"
                                            className="h-14 w-full flex-1 border border-bone/20 bg-transparent px-5 text-base text-bone placeholder:text-bone/35 outline-none transition focus:border-ember"
                                        />
                                        <button
                                            type="submit"
                                            disabled={status === 'loading'}
                                            className="inline-flex h-14 items-center justify-center gap-2 bg-ember px-7 text-sm font-medium uppercase tracking-[0.16em] text-ink transition hover:bg-ember/90 active:scale-[0.98] disabled:opacity-70"
                                        >
                                            {status === 'loading' ? (
                                                <Loader2 className="h-4 w-4 animate-spin" />
                                            ) : (
                                                <>
                                                    Join list
                                                    <ArrowRight className="h-4 w-4" strokeWidth={2} />
                                                </>
                                            )}
                                        </button>
                                    </div>
                                    {error ? <p className="mt-2 text-sm text-red-300">{error}</p> : null}
                                    <p className="mt-3 text-xs text-bone/40">
                                        One email at launch. No newsletters, no sharing your address.
                                    </p>
                                </>
                            )}
                        </motion.form>
                    </div>

                    <motion.div
                        initial={{ opacity: 0, scale: 0.97 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.9, ease: 'easeOut' }}
                        className="relative"
                    >
                        <div className="relative aspect-[3/4] w-full overflow-hidden lg:aspect-[4/5]">
                            <img
                                src={HERO_IMAGE}
                                alt="Healife HBOT hyperbaric oxygen chamber and control unit"
                                className="h-full w-full object-cover"
                                loading="eager"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/10 to-transparent" />
                        </div>
                    </motion.div>
                </section>

                <section aria-hidden="true" className="border-y border-bone/10 py-4">
                    <div className="marquee-mask flex overflow-hidden">
                        {[0, 1].map((copy) => (
                            <div key={copy} className="animate-marquee flex shrink-0 items-center gap-10 pr-10">
                                {MARQUEE.map((word) => (
                                    <span
                                        key={`${copy}-${word}`}
                                        className="flex items-center gap-10 whitespace-nowrap text-xs uppercase tracking-[0.34em] text-bone/45"
                                    >
                                        {word}
                                        <span className="h-1 w-1 rounded-full bg-ember/70" />
                                    </span>
                                ))}
                            </div>
                        ))}
                    </div>
                </section>

                <section className="mx-auto w-full max-w-[72rem] px-6 py-24 md:px-12">
                    <h2 className="max-w-lg font-display text-[clamp(1.9rem,3.4vw,2.9rem)] leading-tight tracking-[-0.02em]">
                        Why choose a Healife hyperbaric oxygen chamber
                    </h2>
                    <div className="mt-14 divide-y divide-bone/10 border-t border-bone/10">
                        {PILLARS.map((item) => (
                            <div key={item.no} className="grid gap-4 py-9 md:grid-cols-[5rem_1fr_1.2fr] md:items-baseline md:gap-10">
                                <span className="font-mono text-xs tracking-widest text-ember">{item.no}</span>
                                <h3 className="font-display text-2xl tracking-[-0.01em]">{item.title}</h3>
                                <p className="text-base leading-relaxed text-bone/60">{item.body}</p>
                            </div>
                        ))}
                    </div>
                    <a
                        href="#signup"
                        className="mt-14 inline-flex items-center gap-3 border-b border-ember pb-1 text-sm uppercase tracking-[0.22em] text-bone transition hover:gap-4"
                    >
                        Join the launch list
                        <ArrowRight className="h-4 w-4 text-ember" strokeWidth={2} />
                    </a>
                </section>
            </main>

            <footer className="relative z-10 border-t border-bone/10">
                <div className="mx-auto flex w-full max-w-[90rem] flex-col gap-4 px-6 py-10 text-xs text-bone/45 md:flex-row md:items-center md:justify-between md:px-12">
                    <p>Healife HBOT</p>
                    <a href="mailto:support@healifehbot.com" className="transition hover:text-bone">
                        support@healifehbot.com
                    </a>
                    <p>&copy; {new Date().getFullYear()} Healife HBOT. All rights reserved.</p>
                </div>
            </footer>
        </div>
    );
};

export default HomePage;
